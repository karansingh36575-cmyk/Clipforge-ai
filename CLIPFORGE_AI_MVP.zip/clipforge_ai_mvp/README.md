# CLIPFORGE AI — MVP

A small Flask-based gaming clip generator for creator-authorized YouTube/Twitch videos.

## What this MVP does
- Accepts YouTube/Twitch URLs using yt-dlp.
- Evaluates candidate windows with FFmpeg audio loudness as a rough highlight proxy.
- Selects 10 or 15 moments spread through the source.
- Crops to 9:16 and renders 720p or 1080p vertical MP4.
- Burns a short storytelling hook onto each clip.
- Provides generated titles, captions and hashtags, individual MP4 downloads and ZIP download.

## Honest limitations
- Audio energy is only a heuristic; it does not understand kills, clutch plays, jokes, or game context.
- This version does not create word-accurate speech subtitles. The text overlay is a hook, not a transcript.
- 1080p output is an upscale if the original source is lower resolution; it cannot restore missing detail.
- Render free instances have 512 MB RAM, sleep after 15 minutes idle, and have ephemeral storage. Long jobs may fail or lose files after restart. Keep source videos short for testing.
- YouTube/Twitch URL extraction can stop working when platforms change. Only process media you own or have explicit permission/licence to download and republish, and comply with platform terms.
- This is a hobby MVP, not production hosting.

## Run locally
Install Python 3.11 and FFmpeg, then:
```bash
pip install -r requirements.txt
python app.py
```
Open http://localhost:7860

## Deploy to Render (Android-friendly workflow)
1. Create a GitHub account and a new **public** repository named `clipforge-ai`.
2. Upload `app.py`, `requirements.txt`, `render.yaml`, and `Dockerfile` to the repository.
3. Create a Render account and connect GitHub.
4. In Render choose **New → Web Service**, select the `clipforge-ai` repository.
5. Choose Free plan and create the service. If deploying manually, select **Docker** as the Environment so Render builds the included `Dockerfile` (which installs FFmpeg).
6. Wait for deployment. Open the `https://...onrender.com` address on your Android phone.
7. First visit after 15 minutes idle may take about a minute to wake up.

## Important Render free-tier notes
Free web services use 512 MB RAM, spin down after 15 minutes idle, and have ephemeral local files. A render/restart can interrupt processing and erase clips. There is no persistent storage on the free instance. Heavy or long 1080p jobs are likely to fail. Use short VODs and test 720p first.

## Recommended test
Start with a 3–5 minute video you own or have permission to use. Select 10 clips at 25 seconds and 720p. The 10/15 setting is a requested output count; very short sources may not provide enough distinct moments.
