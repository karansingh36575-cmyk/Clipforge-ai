import os, re, uuid, shutil, subprocess, threading, json, time
from pathlib import Path
from flask import Flask, request, jsonify, send_file, render_template_string
import yt_dlp

APP = Flask(__name__)
BASE = Path("/tmp/clipforge")
BASE.mkdir(exist_ok=True)
JOBS = {}

PAGE = r"""
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CLIPFORGE AI</title>
<style>
:root{--red:#ff304f;--bg:#08090d;--panel:#12141c;--muted:#9298a8}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 80% 0,#26101a 0,transparent 35%),var(--bg);color:#f5f6fa;font:15px system-ui,Arial}
main{max-width:850px;margin:auto;padding:24px 16px 60px}.brand{display:flex;align-items:center;gap:12px;font-weight:900;letter-spacing:2px;font-size:24px}
.logo{background:var(--red);border-radius:12px;padding:10px 12px;color:white}.tag{color:var(--muted);font-size:12px;letter-spacing:2px;margin:7px 0 24px}
.card{background:var(--panel);border:1px solid #292d39;border-radius:18px;padding:20px;margin:16px 0;box-shadow:0 10px 35px #0005}
h1{font-size:27px;margin:0 0 8px}p{color:var(--muted);line-height:1.55}label{display:block;margin:16px 0 7px;font-weight:650}
input,select{width:100%;padding:14px;border-radius:11px;border:1px solid #343947;background:#090b11;color:white;font-size:15px}
button{border:0;background:var(--red);color:white;font-weight:800;padding:15px 18px;border-radius:12px;width:100%;font-size:16px;margin-top:18px}
small{color:var(--muted)}.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}.check{display:flex;gap:10px;align-items:flex-start;color:#c7cad3;font-size:13px;margin-top:14px}.check input{width:auto;margin-top:3px}
#status{white-space:pre-wrap;color:#d9dce5;font-size:13px;line-height:1.6}.clip{border-top:1px solid #303440;padding:12px 0}.clip a{color:#ff7186;text-decoration:none;font-weight:700}
.pill{display:inline-block;border:1px solid #464b59;border-radius:99px;padding:4px 9px;color:#c6cad4;font-size:11px}
@media(max-width:560px){.row{grid-template-columns:1fr}h1{font-size:23px}}
</style></head><body><main>
<div class="brand"><span class="logo">CF</span> CLIPFORGE AI</div><div class="tag">GAMING HIGHLIGHTS • SHORTS STUDIO</div>
<section class="card"><h1>Turn gameplay into Shorts.</h1><p>Paste a creator-authorized YouTube or Twitch video link. CLIPFORGE will inspect the video, select candidate moments, crop to vertical and export MP4 clips.</p>
<label>Video link</label><input id="url" placeholder="https://www.youtube.com/watch?v=... or Twitch VOD URL">
<div class="row"><div><label>Number of clips</label><select id="count"><option>10</option><option selected>15</option></select></div>
<div><label>Clip length</label><select id="duration"><option value="25">25 seconds</option><option value="35" selected>35 seconds</option><option value="45">45 seconds</option><option value="60">60 seconds</option></select></div></div>
<label>Game / category</label><select id="game"><option>GTA 6</option><option>GTA V</option><option>Fortnite</option><option>Minecraft</option><option>Free Fire</option><option>Other gaming</option></select>
<label>Output quality</label><select id="quality"><option value="1080">1080p Full HD vertical</option><option value="720">720p HD vertical</option></select>
<div class="check"><input type="checkbox" id="rights"><span>I own this video or have permission/licence to download, edit and publish it. I will follow the source platform's terms.</span></div>
<button onclick="startJob()">ANALYZE & CREATE CLIPS</button>
</section>
<section class="card"><h3>Processing status</h3><div id="status">Your clips will appear here after processing starts.</div><div id="results"></div></section>
<p><small>Prototype note: the MVP ranks candidate windows using audio-energy peaks and distributes selections across the video. This is a highlight-finding heuristic, not a guaranteed viral-moment detector. Speech transcription / word-perfect subtitles and advanced AI vision are planned upgrades. Output cannot exceed the source quality.</small></p>
</main>
<script>
let current=null, poller=null;
async function startJob(){
 const url=document.getElementById('url').value.trim();
 if(!url){alert('Paste a video link first.');return}
 if(!document.getElementById('rights').checked){alert('Please confirm you own the video or have permission.');return}
 document.getElementById('results').innerHTML='';
 document.getElementById('status').textContent='Starting…';
 const body={url,count:+document.getElementById('count').value,duration:+document.getElementById('duration').value,game:document.getElementById('game').value,quality:+document.getElementById('quality').value};
 try{
  const r=await fetch('/api/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const d=await r.json(); if(!r.ok) throw new Error(d.error||'Could not start');
  current=d.job_id; poll();
 }catch(e){document.getElementById('status').textContent='Error: '+e.message}
}
async function poll(){
 if(poller)clearInterval(poller);
 async function tick(){
  if(!current)return;
  try{const r=await fetch('/api/jobs/'+current);const d=await r.json();
   document.getElementById('status').textContent=d.message||d.status;
   if(d.status==='done'){
    clearInterval(poller);let html='<p><a class="pill" href="/api/jobs/'+current+'/zip">DOWNLOAD ALL CLIPS (ZIP)</a></p>';
    (d.clips||[]).forEach((c,i)=>{html+='<div class="clip"><b>CLIP '+(i+1)+' — '+c.title+'</b><br><small>'+c.caption+'</small><br><small>'+c.hashtags+'</small><br><a href="'+c.url+'" download>Download MP4</a></div>'});
    document.getElementById('results').innerHTML=html;
   }else if(d.status==='error'){clearInterval(poller)}
  }catch(e){document.getElementById('status').textContent='Connection error: '+e.message}
 }
 await tick();poller=setInterval(tick,4000);
}
</script></body></html>
"""

def allowed_url(url):
    try:
        from urllib.parse import urlparse
        host = (urlparse(url).hostname or "").lower()
        return host in {"youtube.com","www.youtube.com","m.youtube.com","youtu.be","www.twitch.tv","twitch.tv","clips.twitch.tv"}
    except Exception:
        return False

def run(cmd):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or "Command failed")[-1800:])
    return p.stdout + p.stderr

def probe_duration(path):
    out = run(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",str(path)])
    return float(out.strip())

def audio_score(path, start, length):
    # Short-window loudness proxy. A high audio peak may indicate a reaction/action,
    # but is not semantic understanding of gameplay.
    try:
        out = run(["ffmpeg","-hide_banner","-ss",str(start),"-t",str(length),"-i",str(path),
                   "-vn","-af","volumedetect","-f","null","-"])
        m = re.search(r"mean_volume:\s*(-?[\d.]+)\s*dB", out)
        peak = re.search(r"max_volume:\s*(-?[\d.]+)\s*dB", out)
        mean = float(m.group(1)) if m else -60
        mx = float(peak.group(1)) if peak else -60
        return max(mean, -60) + max(mx, -60)*0.25
    except Exception:
        return -100

def make_text(game, n):
    hooks = [
      "WAIT FOR THE LAST SECOND", "THIS GOT OUT OF CONTROL", "THE CLEANEST PLAY?",
      "NOBODY EXPECTED THAT", "ONE MOVE CHANGED EVERYTHING", "WATCH THE FINAL MOMENT",
      "THAT ESCALATED QUICKLY", "CLUTCH OR PURE LUCK?", "THE TIMING WAS PERFECT",
      "HE DID NOT SEE THAT COMING", "BIGGEST PLOT TWIST", "HOW DID THAT HAPPEN?",
      "THE WILDEST MOMENT", "DON'T BLINK", "THAT WAS TOO CLOSE"
    ]
    title = hooks[(n-1) % len(hooks)]
    caption = f"{game} highlight: {title.lower()}. Watch till the end!"
    tags = f"#{game.replace(' ','')} #Gaming #GamingShorts #Gameplay #ViralGaming #Shorts"
    return title, caption, tags

def process_job(job_id, data):
    job = JOBS[job_id]
    folder = BASE / job_id
    folder.mkdir(parents=True, exist_ok=True)
    try:
        job.update(status="working", message="Checking source link…")
        if not allowed_url(data["url"]):
            raise ValueError("Only YouTube and Twitch links are accepted.")
        source = folder / "source.mp4"
        job["message"] = "Downloading authorized source video…"
        ydl_opts = {
            "format": "best[ext=mp4]/best",
            "outtmpl": str(folder / "source.%(ext)s"),
            "merge_output_format": "mp4",
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "socket_timeout": 30,
            "retries": 2,
            "max_filesize": 2 * 1024 * 1024 * 1024,
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(data["url"], download=True)
            downloaded = Path(ydl.prepare_filename(info))
            if not downloaded.exists():
                candidates = list(folder.glob("source.*"))
                candidates = [p for p in candidates if p.suffix.lower() in [".mp4",".mkv",".webm",".mov"]]
                if not candidates: raise RuntimeError("Could not find downloaded media file.")
                downloaded = candidates[0]
        if downloaded != source:
            source = downloaded
        duration = probe_duration(source)
        if duration < 12: raise ValueError("Video is too short to create Shorts.")
        clip_len = min(int(data["duration"]), max(10, int(duration/2)))
        count = int(data["count"])
        # Evaluate overlapping candidate windows at 5-second intervals, then select
        # high-energy windows spread across the full VOD.
        step = max(5, int(clip_len/3))
        candidates = []
        latest = max(0, int(duration-clip_len))
        for start in range(0, latest+1, step):
            if start + clip_len <= duration:
                score = audio_score(source, start, clip_len)
                candidates.append((score, start))
            if len(candidates) > 500: break
        if not candidates:
            candidates = [(0, max(0, int(duration/2-clip_len/2)))]
        candidates.sort(reverse=True)
        chosen=[]
        min_gap=max(clip_len*0.7, duration/(count*2.5))
        for score,start in candidates:
            if all(abs(start-s) >= min_gap for s in chosen):
                chosen.append(start)
            if len(chosen)>=count: break
        if len(chosen)<count:
            for i in range(count):
                s=int(i*max(1,duration-clip_len)/(max(1,count-1)))
                if all(abs(s-x)>=3 for x in chosen): chosen.append(s)
                if len(chosen)>=count:break
        chosen=sorted(chosen[:count])
        clips=[]
        h=int(data["quality"])
        for idx,start in enumerate(chosen,1):
            job["message"]=f"Rendering clip {idx}/{len(chosen)}…"
            title,caption,tags=make_text(data["game"],idx)
            out=folder/f"clip_{idx:02d}.mp4"
            # Vertical 9:16 center crop; scale to chosen height. Text is burned in.
            draw=title.replace(":","").replace("'","")
            vf=f"scale=-2:{h*2},crop={h*9//16}:{h*2},scale=1080:{h*2},crop=ih*9/16:ih,scale=1080:{h*2},drawtext=text='{draw}':fontcolor=white:fontsize=52:box=1:boxcolor=black@0.55:boxborderw=18:x=(w-text_w)/2:y=120"
            # final target: 1080x1920 or 720x1280
            out_w = h
            out_h = int(h * 16 / 9)
            vf=f"scale='if(gt(a,9/16),-2,{out_w})':'if(gt(a,9/16),{out_h},-2)',crop={out_w}:{out_h},drawtext=text='{draw}':fontcolor=white:fontsize={int(h*0.055)}:box=1:boxcolor=black@0.55:boxborderw=14:x=(w-text_w)/2:y=100"
            run(["ffmpeg","-y","-hide_banner","-loglevel","error","-ss",str(start),"-i",str(source),"-t",str(clip_len),
                 "-vf",vf,"-c:v","libx264","-preset","ultrafast","-crf","23","-c:a","aac","-b:a","128k","-movflags","+faststart",str(out)])
            clips.append({"title":title,"caption":caption,"hashtags":tags,"file":out.name})
            job["message"]=f"Rendered {idx}/{len(chosen)} clips."
        job["clips"]=clips
        job["status"]="done"
        job["message"]=f"Finished: {len(clips)} clips ready. Download individually or as ZIP."
        # Clean original to leave space; keep rendered MP4s.
        try: source.unlink()
        except: pass
    except Exception as e:
        job.update(status="error",message=str(e))

@APP.get("/")
def home(): return render_template_string(PAGE)

@APP.get("/health")
def health(): return {"status":"ok","app":"CLIPFORGE AI"}

@APP.post("/api/jobs")
def create_job():
    data=request.get_json(force=True)
    url=str(data.get("url","")).strip()
    if not allowed_url(url): return jsonify(error="Enter a valid YouTube or Twitch video URL."),400
    if data.get("count") not in [10,15]: return jsonify(error="Choose 10 or 15 clips."),400
    if int(data.get("duration",35)) not in [25,35,45,60]: return jsonify(error="Invalid clip duration."),400
    if int(data.get("quality",1080)) not in [720,1080]: return jsonify(error="Invalid output quality."),400
    jid=uuid.uuid4().hex[:12]
    JOBS[jid]={"status":"queued","message":"Queued…","clips":[]}
    threading.Thread(target=process_job,args=(jid,data),daemon=True).start()
    return jsonify(job_id=jid)

@APP.get("/api/jobs/<jid>")
def get_job(jid):
    if jid not in JOBS:return jsonify(error="Job not found. The free server may have restarted."),404
    j=JOBS[jid]
    clips=[{"title":c["title"],"caption":c["caption"],"hashtags":c["hashtags"],"url":f"/api/jobs/{jid}/clip/{c['file']}"} for c in j.get("clips",[])]
    return jsonify(status=j["status"],message=j["message"],clips=clips)

@APP.get("/api/jobs/<jid>/clip/<filename>")
def get_clip(jid,filename):
    if jid not in JOBS:return "Job expired",404
    path=BASE/jid/filename
    if not path.exists() or path.suffix!=".mp4":return "Clip not found",404
    return send_file(path,as_attachment=True,download_name=filename)

@APP.get("/api/jobs/<jid>/zip")
def get_zip(jid):
    if jid not in JOBS:return "Job expired",404
    folder=BASE/jid
    clips=list(folder.glob("clip_*.mp4"))
    if not clips:return "No clips ready",404
    import zipfile
    zpath=folder/"clipforge_clips.zip"
    with zipfile.ZipFile(zpath,"w",zipfile.ZIP_DEFLATED) as z:
        for p in clips:z.write(p,p.name)
    return send_file(zpath,as_attachment=True,download_name="CLIPFORGE_AI_Clips.zip")

if __name__=="__main__":
    APP.run(host="0.0.0.0",port=int(os.environ.get("PORT",7860)))
